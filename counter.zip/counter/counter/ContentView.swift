//
//  ContentView.swift
//  counter
//
//  Created by Anil on 04/03/26.
//

import SwiftUI


class ContentViewModel: ObservableObject {
    @Published var count = 0
    
    func increment(){
        count += 1
    }
    
    func decrement(){
        count -= 1
    }
}

struct ContentView: View {
    @StateObject var viewModel = ContentViewModel()
    //@State private var count:Int = 0
    var body: some View {
        VStack {
            
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Count \(viewModel.count)")
            
            Button("Incress Count"){
                viewModel.increment()
            }
            
            Button("Decress Count"){
                viewModel.decrement()
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
