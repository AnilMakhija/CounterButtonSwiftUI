//
//  counterApp.swift
//  counter
//
//  Created by Anil on 04/03/26.
//

import SwiftUI

@main
struct counterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
